---
layout: group
title: NetSec
filename: netsec
permalink: committees/netsec
tagline: Cybersecurity Made Simple
hex: FFBA44
---

{% include "colorswatch.html", name: "NetSec Amber", hex: "#FFBA44", rgb: "(255, 186, 68)" %}
{% include "colorswatch.html", name: "NetSec Tint", hex: "#EDCD98", rgb: "(237, 205, 152)" %}
{% include "colorswatch.html", name: "NetSec Black", hex: "#3A3327", rgb: "(58, 51, 39)" %}
{% include "colorswatch.html", name: "NetSec Secondary", hex: "#1EBDF4", rgb: "(30, 189, 244)" %}
