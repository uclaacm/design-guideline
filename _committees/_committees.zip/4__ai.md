---
layout: group
title: AI
filename: ai
permalink: committees/ai
tagline: Learning Machine Learning
hex: 1EBDF4
---
{% include "colorswatch.html", name: "AI Arctic", hex: "#1EBDF4", rgb: "(30, 189, 244)" %}
{% include "colorswatch.html", name: "AI Tint", hex: "#94D8F0", rgb: "(148, 216, 240)" %}
{% include "colorswatch.html", name: "AI Black", hex: "#233339", rgb: "(35, 51, 57)" %}
{% include "colorswatch.html", name: "AI Secondary", hex: "#C960FF", rgb: "(201, 96, 255)" %}
