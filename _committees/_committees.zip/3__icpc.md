---
layout: group
title: ICPC
filename: icpc
permalink: committees/icpc
tagline: Mastering Algorithms and Competitive Programming
hex: FF6B6B
---
{% include "colorswatch.html", name: "ICPC Tangerine", hex: "#FF6B6B", rgb: "(255, 107, 107)" %}
{% include "colorswatch.html", name: "ICPC Tint", hex: "#EEAEAE", rgb: "(238, 174, 174)" %}
{% include "colorswatch.html", name: "ICPC Black", hex: "#3A2B2B", rgb: "(58, 43, 43)" %}
{% include "colorswatch.html", name: "ICPC Secondary", hex: "#1BC3A9", rgb: "(27, 195, 169)" %}

