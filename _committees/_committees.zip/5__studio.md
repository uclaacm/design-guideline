---
layout: group
title: Studio
filename: studio
permalink: committees/studio
tagline: Creative Expression through Games and VR
hex: ED3266
---
{% include "colorswatch.html", name: "Studio Raspberry", hex: "#ED3266", rgb: "(237, 50, 102)" %}
{% include "colorswatch.html", name: "Studio Tint", hex: "#F09FB0", rgb: "(240, 159, 176)" %}
{% include "colorswatch.html", name: "ICPC Black", hex: "#3A2B2B", rgb: "(58, 43, 43)" %}
{% include "colorswatch.html", name: "Studio Secondary", hex: "#FF6B6B", rgb: "(255, 107, 107)" %}
